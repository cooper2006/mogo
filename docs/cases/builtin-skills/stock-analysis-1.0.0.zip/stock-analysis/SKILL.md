---
name: stock-analysis
displayName: 个股分析
packageName: stock-analysis
version: 1.0.0
description: 对单只上市公司做财务、资金与股东维度的深度分析与风险复核。
whenToUse: 需要对单只上市公司做财务、资金与股东维度的深度分析并产出报告时使用（原声明意图 intent == "stock_analysis"）。
inputs:
  - company_name
  - ts_code (optional)
  - output_spec (optional)
outputs:
  - report.md
tools:
  - search_web
  - get_stock_basic_info
  - get_stock_daily
  - get_stock_financial
  - get_stock_forecast
  - get_stock_moneyflow
  - get_top10_holders
  - get_main_business
  - get_report_dates
steps:
  - resolve_company_code
  - fetch_news
  - fetch_financials
  - analyze_trends
  - compose_report
validation:
  required_sections:
    - Conclusion
    - Evidence
    - Risks
  must_include_fields:
    - Data source
    - Date range
resources:
  - templates/report.md
  - scripts/normalize_stock_code.py
  - validation.yaml
---

# 目的

单只上市公司的深度分析技能：拉取行情、财务、资金流、股东与主营业务数据，结合新闻面做趋势判断，产出带数据来源与数据区间的报告（含独立的风险章节）。面向用户直接调用。

# 步骤

1. `resolve_company_code`：用 `scripts/normalize_stock_code.py` 把公司名或代码归一为统一的 `ts_code`；入参已给 `ts_code` 时直接校验使用。
2. `fetch_news`：用 `search_web` 收集近期新闻、公告与舆情。
3. `fetch_financials`：调用 `get_stock_basic_info`、`get_stock_daily`、`get_stock_financial`、`get_stock_forecast`、`get_stock_moneyflow`、`get_top10_holders`、`get_main_business`、`get_report_dates` 获取所需数据。
4. `analyze_trends`：从经营趋势、财务质量、资金与股东结构三方面分析，结论与证据一一对应。
5. `compose_report`：按 `templates/report.md` 的结构成文。

# 执行说明

- 报告必须包含 `Conclusion`、`Evidence`、`Risks` 三节，结构校验以 `validation.yaml` 的 `required_sections` 为准。
- 必须写明 `Data source` 与 `Date range` 两个字段（见 `validation.yaml` 的 `must_include_fields`）。
- 取不到的字段标注为"数据缺失"，不得估算或编造数值；区间不一致的数据要在 `Evidence` 中说明口径。
- 传入 `output_spec` 时按其约束篇幅、语言与结构。
