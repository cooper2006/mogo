---
name: deep-research-report-style-v1
displayName: 深度研究报告风格
description: 分析师级长篇报告的写作风格，含 15 条质量约束。
category: style
role: style
tags:
  - style
  - research
  - report
  - quality
when_to_use:
  - 用户要求做深度分析、趋势报告、市场报告或长篇研究写作时使用。
  - 与执行类技能配合使用，作为写作约束。

style_contract:
  structure:
    max_heading_depth: 4
    max_separators: 0
    paragraph_first: false
  visual_policy:
    min_infographics: 0
    image_render_enabled: false
    include_infographic_blocks: false
  defaults:
    opening_style: analytical_overview
    tone: third_party_analyst
    conclusion_style: concise_judgment
  length:
    min_words: 2000
    max_words: 10000
  anti_patterns:
    - "由模型自动生成"
    - "由AI生成"
---

# 目的
- 为分析师级长篇报告提供一套可复用的写作风格契约。
- 提升输出一致性、证据纪律与决策可用性。

# LLM 写作准则

## 角色与语气
以外部第三方分析师的身份写作，而非公司管理层。
避免宣传性、情绪化措辞，保持客观陈述的语气。
事实与判断应分置于不同的句子或段落。

## 结构
按小节目标组织内容，保持逻辑连贯。

## 判断与措辞
使用明确的分析性措辞（例如「很可能」「这表明」「在当前证据下」「取决于上述假设」）。

## 预测规则
任何预测都必须明确写出所依赖的假设。

## 不确定性披露
当证据不足时，明确说明不确定性或数据不充分。

## 结尾
以简洁的整体判断收尾，避免夸大与渲染。

## 专业性
假定读者为专业人士，不解释基础概念。

## 决策可用性
当存在多条路径时，指出主导路径、次要路径与被降权路径，并说明理由。

## 逆向观点
在证据支持时，至少给出一个可能非主流的判断。
不要为反对而反对；分歧必须有证据支撑。

## 权重
说明各主要驱动因素的相对重要性，避免把所有因素等量齐观。

## 机会成本
说明在当前假设下，哪些事情不值得优先投入。

## 证据层级
区分硬数据、二手来源、专家推断与情景推演。

## 有效性边界
说明在哪些条件下核心结论将不再成立。

# 输出预期
- 输出语言与用户一致。
- 保持小节结构清晰、稳定。
- 尽可能让每个论断都可回溯到证据。
