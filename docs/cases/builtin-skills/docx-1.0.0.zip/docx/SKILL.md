---
name: docx
displayName: Word 文档处理
description: "专业文档的创建、编辑与分析，支持修订留痕、批注、格式保留与文本提取。当你需要处理专业文档（.docx 文件）来做以下事情时使用：(1) 创建新文档，(2) 修改或编辑内容，(3) 处理修订留痕，(4) 添加批注，或其他任何文档任务"
license: Proprietary. LICENSE.txt has complete terms
---

# DOCX 文档的创建、编辑与分析

## 概述

用户可能让你创建、编辑或分析 .docx 文件的内容。.docx 文件本质上是一个 ZIP 归档，内含 XML 文件与其他资源，可以读取和编辑。不同任务有不同的工具与流程可用。

## 流程决策树

### 读取/分析内容
使用下面的「文本提取」或「原始 XML 访问」小节

### 创建新文档
使用「创建新的 Word 文档」流程

### 编辑既有文档
- **自己的文档 + 简单改动**
  使用「基础 OOXML 编辑」流程

- **他人的文档**
  使用 **「修订留痕流程」**（推荐的默认做法）

- **法律、学术、商务或政府文档**
  使用 **「修订留痕流程」**（必需）

## 读取与分析内容

### 文本提取
如果只需要读取文档的文本内容，应先用 pandoc 把文档转成 Markdown。pandoc 对文档结构的保留支持很好，也能展示修订留痕：

```bash
# 带修订留痕转换为 Markdown
pandoc --track-changes=all path-to-file.docx -o output.md
# 可选值：--track-changes=accept/reject/all
```

### 原始 XML 访问
以下场景需要访问原始 XML：批注、复杂格式、文档结构、内嵌媒体与元数据。遇到这些特性时，需要先解包文档再读取其原始 XML 内容。

#### 解包文件
`python ooxml/scripts/unpack.py <office_file> <output_directory>`

#### 关键文件结构
* `word/document.xml` —— 主文档内容
* `word/comments.xml` —— document.xml 中引用的批注
* `word/media/` —— 内嵌图片与媒体文件
* 修订留痕使用 `<w:ins>`（插入）与 `<w:del>`（删除）标签

## 创建新的 Word 文档

从零创建 Word 文档时，使用 **docx-js**，它允许你用 JavaScript/TypeScript 生成 Word 文档。

### 流程
1. **必做 —— 完整读取文件**：从头到尾完整读取 [`docx-js.md`](docx-js.md)（约 500 行）。**读取该文件时绝不要设置任何范围限制。** 在开始创建文档前，通读全文以掌握详细语法、关键格式规则与最佳实践。
2. 用 Document、Paragraph、TextRun 等组件创建一个 JavaScript/TypeScript 文件（可假定依赖均已安装；若未安装，参见下方依赖小节）
3. 用 Packer.toBuffer() 导出为 .docx

### 渲染 Markdown（项目默认方式）

使用内置渲染器以保留当前项目的格式：

```bash
python scripts/render_markdown.py /path/to/report.md output.docx
```

## 编辑既有 Word 文档

编辑既有 Word 文档时，使用 **Document 库**（一个用于 OOXML 操作的 Python 库）。该库会自动处理基础设施的搭建，并提供文档操作的方法。遇到复杂场景，可以直接通过该库访问底层 DOM。

### 流程
1. **必做 —— 完整读取文件**：从头到尾完整读取 [`ooxml.md`](ooxml.md)（约 600 行）。**读取该文件时绝不要设置任何范围限制。** 通读全文以掌握 Document 库的 API，以及直接编辑文档文件的 XML 模式。
2. 解包文档：`python ooxml/scripts/unpack.py <office_file> <output_directory>`
3. 使用 Document 库编写并运行一个 Python 脚本（参见 ooxml.md 的「Document Library」小节）
4. 打包最终文档：`python ooxml/scripts/pack.py <input_directory> <office_file>`

Document 库既提供常用操作的高层方法，也提供复杂场景下的直接 DOM 访问。

## 文档审阅的修订留痕流程

本流程允许你先用 Markdown 规划完整的修订留痕，再在 OOXML 中落地。**关键**：要做完整的修订留痕，必须系统性地落实每一处修改。

**分批策略**：把相关改动按 3-10 处一批分组。这样既能控制调试难度，又能保持效率。每批测试通过后再进入下一批。

**原则：最小、精确的编辑**
落地修订留痕时，只标记真正发生变化的文本。把未变化的文本也重复一遍会让改动难以审阅，且显得不专业。把替换拆成：[未变文本] + [删除] + [插入] + [未变文本]。未变文本要保留原 run 的 RSID——从原文提取 `<w:r>` 元素并复用。

示例 —— 把句子中的 "30 days" 改成 "60 days"：
```python
# 反例 —— 整句替换
'<w:del><w:r><w:delText>The term is 30 days.</w:delText></w:r></w:del><w:ins><w:r><w:t>The term is 60 days.</w:t></w:r></w:ins>'

# 正例 —— 只标记变化的部分，未变文本复用原 <w:r>
'<w:r w:rsidR="00AB12CD"><w:t>The term is </w:t></w:r><w:del><w:r><w:delText>30</w:delText></w:r></w:del><w:ins><w:r><w:t>60</w:t></w:r></w:ins><w:r w:rsidR="00AB12CD"><w:t> days.</w:t></w:r>'
```

### 修订留痕流程

1. **获取 Markdown 表示**：在保留修订留痕的前提下把文档转成 Markdown：
   ```bash
   pandoc --track-changes=all path-to-file.docx -o current.md
   ```

2. **识别并分组改动**：通读文档，列出所有需要修改的地方，并按逻辑分批：

   **定位方法**（用于在 XML 中找到改动点）：
   - 章节/标题编号（如「第 3.2 节」「第四条」）
   - 如果段落有编号，用段落标识
   - 用带唯一上下文文本的 grep 模式
   - 文档结构（如「第一段」「签署栏」）
   - **不要使用 Markdown 行号** —— 它们与 XML 结构不对应

   **分批组织**（每批 3-10 处相关改动）：
   - 按章节：「第 1 批：第 2 节修订」「第 2 批：第 5 节更新」
   - 按类型：「第 1 批：日期更正」「第 2 批：主体名称变更」
   - 按复杂度：先用简单的文本替换，再处理复杂的结构性改动
   - 按顺序：「第 1 批：第 1-3 页」「第 2 批：第 4-6 页」

3. **阅读文档并解包**：
   - **必做 —— 完整读取文件**：从头到尾完整读取 [`ooxml.md`](ooxml.md)（约 600 行）。**读取该文件时绝不要设置任何范围限制。** 特别留意「Document Library」与「Tracked Change Patterns」两节。
   - **解包文档**：`python ooxml/scripts/unpack.py <file.docx> <dir>`
   - **记下建议的 RSID**：解包脚本会为你的修订留痕建议一个 RSID，把它抄下来，第 4b 步要用。

4. **分批落地改动**：按逻辑分组（按章节、按类型或按位置邻近度），在同一个脚本里一起实现。这样做的好处：
   - 更易调试（批次越小，越容易定位错误）
   - 可以增量推进
   - 保持效率（每批 3-10 处改动比较合适）

   **建议的分批方式：**
   - 按文档章节（如「第 3 节改动」「定义」「终止条款」）
   - 按改动类型（如「日期变更」「主体名称更新」「法律术语替换」）
   - 按位置邻近（如「第 1-3 页的改动」「文档前半部分的改动」）

   对每一批相关改动：

   **a. 把文本映射到 XML**：在 `word/document.xml` 中 grep 目标文本，确认文本是如何被拆分到多个 `<w:r>` 元素里的。

   **b. 编写并运行脚本**：用 `get_node` 找到节点，落地修改，然后 `doc.save()`。模式参见 ooxml.md 的 **「Document Library」** 一节。

   **注意**：每次写脚本前都要立刻重新 grep `word/document.xml`，以获取当前行号并核对文本内容。行号在每次脚本运行后都会变。

5. **打包文档**：所有批次完成后，把解包目录转回 .docx：
   ```bash
   python ooxml/scripts/pack.py unpacked reviewed-document.docx
   ```

6. **最终校验**：对整份文档做一次完整检查：
   - 把最终文档转成 Markdown：
     ```bash
     pandoc --track-changes=all reviewed-document.docx -o verification.md
     ```
   - 核验所有改动都已正确应用：
     ```bash
     grep "original phrase" verification.md  # 应该找不到
     grep "replacement phrase" verification.md  # 应该能找到
     ```
   - 检查是否引入了非预期的改动


## 把文档转成图片

要直观分析 Word 文档，用两步流程把它转成图片：

1. **把 DOCX 转成 PDF**：
   ```bash
   soffice --headless --convert-to pdf document.docx
   ```

2. **把 PDF 页面转成 JPEG 图片**：
   ```bash
   pdftoppm -jpeg -r 150 document.pdf page
   ```
   这会生成 `page-1.jpg`、`page-2.jpg` 等文件。

参数说明：
- `-r 150`：分辨率设为 150 DPI（在质量与体积之间权衡）
- `-jpeg`：输出 JPEG 格式（如偏好 PNG 可用 `-png`）
- `-f N`：起始页（如 `-f 2` 表示从第 2 页开始）
- `-l N`：结束页（如 `-l 5` 表示到第 5 页为止）
- `page`：输出文件的前缀

指定页码范围示例：
```bash
pdftoppm -jpeg -r 150 -f 2 -l 5 document.pdf page  # 只转换第 2-5 页
```

## 代码风格约定
**重要**：为 DOCX 操作生成代码时：
- 写简洁的代码
- 避免冗长的变量名与多余操作
- 避免不必要的 print 语句

## 依赖

所需依赖（未安装则先安装）：

- **pandoc**：`sudo apt-get install pandoc`（用于文本提取）
- **docx**：`npm install -g docx`（用于创建新文档）
- **LibreOffice**：`sudo apt-get install libreoffice`（用于 PDF 转换）
- **Poppler**：`sudo apt-get install poppler-utils`（用于 pdftoppm 把 PDF 转成图片）
- **defusedxml**：`pip install defusedxml`（用于安全的 XML 解析）
