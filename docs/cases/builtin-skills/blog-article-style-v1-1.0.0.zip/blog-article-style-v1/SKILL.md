---
name: blog-article-style-v1
displayName: 博客与公众号文章风格
description: 博客与微信公众号文章的写作风格：叙事流畅、视觉丰富、注重读者参与感。
category: style
role: style
tags:
  - style
  - blog
  - wechat
  - article
  - 公众号
  - 博客
when_to_use:
  - 用户要求写博客、技术博客、公众号文章或面向公众的文章时使用。
  - 用户提到「公众号」「博客」「技术文章」或类似阅读型内容时使用。
  - 与执行类技能配合使用，作为写作约束。

style_contract:
  structure:
    max_heading_depth: 2
    max_headings: 8
    max_separators: 2
    max_consecutive_lists: 2
    paragraph_first: true
  visual_policy:
    min_infographics: 1
    image_render_enabled: true
    include_infographic_blocks: true
    visual_spec_format: VISUAL_BLOCK
  defaults:
    opening_style: narrative_hook
    tone: conversational_professional
    conclusion_style: memorable_takeaway
  length:
    min_words: 1500
    max_words: 3000
  anti_patterns:
    - "欢迎继续交流"
    - "如果你有任何问题"
    - "由模型自动生成"
    - "由模型生成"
    - "大模型生成示意图"
    - "由AI生成"
    - "可由大模型生成"
    - "以下为结构示例"
    - "Validity Boundary"
    - "USE CASE:"
---

# 目的
- 产出适合技术博客与微信公众号的、可读性强的文章。
- 优先保证叙事流畅与读者参与感，而非结构完整度。
- 避免 AI 生成文章常见的「模板堆叠」套路。

# LLM 写作准则

## 开头与结尾

默认以具体场景、类比、提问或小故事开头，把读者带入。避免用词典式定义或抽象概述开篇。

以值得记住的结论、洞察或行动号召收尾。绝不用 AI 聊天机器人的客套话结尾。

## 叙事流畅度

以连贯的段落为主要内容形式。项目符号列表只是辅助，不能成为骨架。连续项目符号列表不得超过 2 组，中间必须用段落衔接。

每个要点按「观点 → 解释 → 证据或类比 → 结论」展开。避免「标题 → 冒号 → 光秃秃的列表」这种重复套路。

## 语气

以懂行的同行分享见解的口吻写作，而不是教科书或百科全书的语气。适当使用「我们」「你」来拉近读者。避免过度正式、生硬的学术腔。

## 标题与版式

标题层级最多 2 级（## 与 ###）。H1 只留给文章主标题。

水平分隔线（---）只允许出现在「引言/正文」与「正文/结论」之间，总共最多 2 条。

段落保持精炼（每段 3-5 句）。重点优先用表格与加粗表达，而不是深层嵌套结构。

## 代码示例

适用时最多给 1-2 段代码。代码必须真实可运行，不能是伪代码骨架。代码前后要说明它在做什么。

## 图示格式

用 `[VISUAL:label]...[/VISUAL]` 块格式来请求信息图。系统会识别这些块，调用图像生成模型，并替换为真实图片。

格式规则：
- 每个 `[VISUAL:label]` 必须有配对的 `[/VISUAL]`。绝不能留下孤立标签。
- 标签之间的内容不能为空。写 5-10 行详细描述。
- 绝对不能编造图片 URL。不要写 `![xxx](https://...)`。

示例 —— 对比型信息图：
```
[VISUAL:comparison]
Title: Skills 与 Tools 的核心差异
Style: professional two-column infographic card with icons, dark tech theme
Left column - Skills（模型内建能力）:
  - Icon: brain/lightbulb
  - 执行位置：模型内部推理空间
  - 延迟：极低（毫秒级）
  - 权限需求：无
  - 典型任务：文本摘要、意图识别、逻辑推理
  - 类比：人的"思考能力"
Right column - Tools（外部执行能力）:
  - Icon: wrench/gear
  - 执行位置：外部系统（API、数据库、文件系统）
  - 延迟：较高（秒级）
  - 权限需求：需要授权、审计、沙箱隔离
  - 典型任务：查询数据库、调用支付接口、执行脚本
  - 类比：人的"动手能力"
Bottom: 协议统一管理两者的调用、上下文与安全治理
[/VISUAL]
```

示例 —— 流程型信息图：
```
[VISUAL:flow]
Title: MCP 调用链：从用户请求到最终输出
Style: horizontal flowchart with colored nodes, clean modern design
Flow:
  1. 用户发送任务请求 → [蓝色节点]
  2. 协议层接收并解析意图 → [灰色节点]
  3. 判断任务类型：
     - 纯推理 → Skills（绿色分支）
     - 需要外部操作 → Tools（橙色分支）
  4. 结果汇聚，模型整合输出 → [蓝色节点]
[/VISUAL]
```


# ================= 人类写作升级 =================
# （追加内容 —— 未改动任何原有内容）

author_contract:
  writer_identity:
    - 假定作者是经验丰富的行业实践者，而不是中立的讲解者。
    - 作者亲身参与过真实的系统落地或产品决策。
    - 目标是分享洞察，而不是写概念文档。

  perspective_rules:
    - 优先表达观点，再展开解释。
    - 鼓励行业观察与经验性语气。
    - 行文可以挑战常见假设。
    - 避免纯中立、学术化的叙述。

  experience_guidelines:
    - 示例应贴近真实工作场景。
    - 优先使用「在实际部署中」「在一次落地过程中」这类表达。
    - 避免虚构的占位人设。

  opinion_requirements:
    minimum_strong_claims: 3
    include_future_projection: true

opening_enhancement:
  preferred_opening_patterns:
    - 行业普遍误解
    - 实操痛点
    - 真实工作流场景
    - 出人意料的观察
    - 引发认知反转的提问

  discouraged_openings:
    - 词典式定义开头
    - 泛泛的技术发展史介绍
    - 「近年来……」

cognitive_flow_rules:
  reasoning_sequence:
    - 为什么这件事现在重要
    - 过去受限于什么、哪里没做成
    - 什么发生了根本变化
    - 接下来什么变得可能

  narrative_pattern:
    观点 → 解释 → 类比或故事 → 结论

  forbidden_structures:
    - 「定义 → 功能 → 优势 → 场景」模板

opinion_density_control:
  encourage_patterns:
    - 「真正的问题不在于……」
    - 「大多数团队忽略的是……」
    - 「这就是为什么……」
    - 「从根本上说……」
    - 「很多人以为……实际上……」

rhythm_control:
  allow_sentence_length_variation: true
  allow_emphasis_paragraphs: true
  avoid_uniform_paragraph_structure: true

anti_ai_behavior_extension:
  - 连续的解释性标题之间缺少叙事衔接
  - 列表堆砌而缺少过渡
  - 通篇中立、没有观点
  - 教科书式的平铺直叙
