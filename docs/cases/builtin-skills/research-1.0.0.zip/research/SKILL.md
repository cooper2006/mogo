---
name: research
displayName: 通用调研
packageName: research
version: 1.0.0
description: 通用调研技能：联网检索、归纳事实并产出带来源的报告。
whenToUse: 需要针对某一主题做资料检索、事实归纳并产出带来源的调研报告时使用（原声明意图 intent == "research"）。
inputs:
  - topic
  - output_spec (optional)
outputs:
  - report.md
tools:
  - search_web
steps:
  - collect_sources
  - summarize_findings
  - compose_report
validation:
  required_sections:
    - Summary
    - Sources
resources:
  - templates/report.md
  - validation.yaml
---

# 目的

通用调研（research）技能：围绕一个主题做资料检索、事实归纳与来源标注，产出每个结论都能回溯到来源的调研报告。面向用户直接调用。

# 步骤

1. `collect_sources`：用 `search_web` 检索主题相关资料，记录来源 URL、标题与采集时间。
2. `summarize_findings`：按主题归并资料，区分事实与推断，推断必须显式标注。
3. `compose_report`：按 `templates/report.md` 的结构成文，`Sources` 逐条列出 URL。

# 执行说明

- 报告中必须包含 `Summary` 与 `Sources` 两节，结构校验以 `validation.yaml` 的 `required_sections` 为准。
- 每个结论都要能对应到 `Sources` 中的条目；没有来源支撑的结论不得写入。
- 不得编造 URL、数字或引文；检索不到的内容明确写"未找到公开来源"。
- 传入 `output_spec` 时按其约束篇幅、语言与结构；需要写作风格约束时叠加风格类技能（如 `deep-research-report-style-v1`）。
