---
name: mogo-builtin-skills
displayName: 内置技能合集
description: 需要处理 Office / PDF 文档、为交付物套用主题样式，或做竞品调研、财务分析、市场情报、舆情监测与报告综合时使用本专家包。
version: 1.0.0
orchestration:
  children:
    - blog-article-style-v1
    - deep-research-report-style-v1
    - docx
    - financial-analysis-v1
    - market-intelligence-v1
    - pdf
    - pptx
    - product-analysis-v1
    - report-synthesis-v1
    - research
    - sentiment-monitor-v1
    - stock-analysis
    - theme-factory
    - xlsx
---
本专家包内含全部内置技能。按用户诉求选择对应的子技能：

- 文档与交付物：`docx`（Word）、`xlsx`（Excel）、`pptx`（演示文稿）、`pdf`（PDF）、`theme-factory`（主题样式）
- 竞品深度调研链：`market-intelligence-v1` → `product-analysis-v1` → `financial-analysis-v1` → `sentiment-monitor-v1` → `report-synthesis-v1`
- 单点分析：`stock-analysis`（个股）、`research`（通用调研）
- 写作风格约束：`blog-article-style-v1`、`deep-research-report-style-v1`

先读「Internal child Skill directory」确认各子技能的职责与适用场景，再按需完整读取对应子技能的全部指令。多个子技能可组合使用（例如先调研、再综合、最后套主题出稿）。
