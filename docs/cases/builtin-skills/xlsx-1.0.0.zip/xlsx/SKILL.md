---
name: xlsx
displayName: Excel 表格处理
description: "只要电子表格文件是主要输入或输出，就使用本技能。凡是用户想要：打开、读取、编辑或修复既有的 .xlsx、.xlsm、.csv 或 .tsv 文件（例如加列、写公式、设置格式、作图、清洗脏数据）；从零或从其它数据源新建电子表格；或在几种表格文件格式之间转换时，都适用。当用户按文件名或路径提到某个表格文件（哪怕是随口一提，比如「我下载目录里那个 xlsx」），并希望对其做点什么或由它产生点什么时，尤其要触发。把杂乱表格数据（错行、错位表头、垃圾数据）清洗或重构为规范电子表格时，也要触发。交付物必须是电子表格文件。当主要交付物是 Word 文档、HTML 报告、独立 Python 脚本、数据库流水线或 Google Sheets API 集成时，不要触发本技能，即使其中涉及表格数据。"
license: Proprietary. LICENSE.txt has complete terms
---

# 交付物要求

## 所有 Excel 文件

### 专业字体
- 除非用户另有指示，所有交付物都使用统一、专业的字体（如 Arial、Times New Roman）

### 公式零错误
- 每个 Excel 模型交付时都**必须**做到公式零错误（#REF!、#DIV/0!、#VALUE!、#N/A、#NAME?）

### 保留既有模板（更新模板时）
- 修改文件时，先研究并**完全**沿用既有的格式、样式与约定
- 绝不要对已有既定规范的文件强加标准化格式
- 既有模板的约定**始终**优先于本指南

## 财务模型

### 颜色编码标准
除非用户或既有模板另有说明

#### 行业标准颜色约定
- **蓝色文字（RGB: 0,0,255）**：硬编码的输入值，以及用户做情景分析时会改动的数字
- **黑色文字（RGB: 0,0,0）**：**所有**公式与计算
- **绿色文字（RGB: 0,128,0）**：引用同一工作簿内其它工作表的链接
- **红色文字（RGB: 255,0,0）**：指向其它文件的外部链接
- **黄色背景（RGB: 255,255,0）**：需要关注的关键假设，或待更新的单元格

### 数字格式标准

#### 必守格式规则
- **年份**：按文本字符串格式（如 "2024"，而不是 "2,024"）
- **货币**：使用 $#,##0 格式；表头中**务必**标明单位（如「营业收入（百万美元）」）
- **零值**：用数字格式把所有零显示为 "-"，百分比同理（如 "$#,##0;($#,##0);-"）
- **百分比**：默认用 0.0% 格式（保留一位小数）
- **倍数**：估值倍数（EV/EBITDA、P/E）格式化为 0.0x
- **负数**：用括号 (123)，而不是负号 -123

### 公式编写规则

#### 假设的存放位置
- 把**所有**假设（增长率、利润率、倍数等）放在单独的假设单元格里
- 公式中使用单元格引用，而不是硬编码的数值
- 示例：用 =B5*(1+$B$6)，而不是 =B5*1.05

#### 公式错误预防
- 核对所有单元格引用是否正确
- 检查区间是否存在差一位（off-by-one）错误
- 确保所有预测期使用的公式一致
- 用边界情况测试（零值、负数）
- 确认没有意外的循环引用

#### 硬编码值的注释要求
- 在批注中或紧邻的单元格里（若位于表格末尾）说明来源。格式："来源：[系统/文档]，[日期]，[具体出处]，[URL（如适用）]"
- 示例：
  - "来源：公司 10-K 年报，FY2024，第 45 页，收入附注，[SEC EDGAR URL]"
  - "来源：公司 10-Q 季报，2025 年 Q2，附件 99.1，[SEC EDGAR URL]"
  - "来源：Bloomberg 终端，2025/8/15，AAPL US Equity"
  - "来源：FactSet，2025/8/20，一致预期筛选"

# XLSX 的创建、编辑与分析

## 概述

用户可能会要求你创建、编辑或分析 .xlsx 文件的内容。针对不同任务，你有不同的工具与工作流可用。

## 重要要求

**重算公式需要 LibreOffice**：可以假定已安装 LibreOffice，用于通过 `scripts/recalc.py` 脚本重算公式取值。该脚本首次运行时会自动配置 LibreOffice，在 Unix socket 受限制的沙箱环境中同样有效（由 `scripts/office/soffice.py` 处理）

## 读取与分析数据

### 用 pandas 做数据分析
做数据分析、可视化与基本操作时，使用 **pandas**，它提供了强大的数据操作能力：

```python
import pandas as pd

# 读取 Excel
df = pd.read_excel('file.xlsx')  # 默认：第一个工作表
all_sheets = pd.read_excel('file.xlsx', sheet_name=None)  # 所有工作表，返回字典

# 分析
df.head()      # 预览数据
df.info()      # 列信息
df.describe()  # 统计量

# 写出 Excel
df.to_excel('output.xlsx', index=False)
```

## Excel 文件工作流

## 关键：用公式，不要硬编码数值

**务必使用 Excel 公式，不要先在 Python 里算好再把数值写死。** 这样才能保证表格保持动态、可更新。

### ❌ 错误做法——硬编码算好的数值
```python
# 差：在 Python 里算好并写死结果
total = df['Sales'].sum()
sheet['B10'] = total  # 把 5000 写死

# 差：在 Python 里计算增长率
growth = (df.iloc[-1]['Revenue'] - df.iloc[0]['Revenue']) / df.iloc[0]['Revenue']
sheet['C5'] = growth  # 把 0.15 写死

# 差：用 Python 计算平均值
avg = sum(values) / len(values)
sheet['D20'] = avg  # 把 42.5 写死
```

### ✅ 正确做法——使用 Excel 公式
```python
# 好：让 Excel 自己求和
sheet['B10'] = '=SUM(B2:B9)'

# 好：增长率用 Excel 公式
sheet['C5'] = '=(C4-C2)/C2'

# 好：平均值用 Excel 函数
sheet['D20'] = '=AVERAGE(D2:D19)'
```

这适用于**所有**计算——合计、百分比、比率、差额等。源数据变化时，表格应当能自行重算。

## 常用工作流
1. **选工具**：数据用 pandas，公式/格式用 openpyxl
2. **新建/加载**：新建工作簿，或加载既有文件
3. **修改**：增删改数据、公式与格式
4. **保存**：写入文件
5. **重算公式（用了公式就必做）**：使用 scripts/recalc.py 脚本
   ```bash
   python scripts/recalc.py output.xlsx
   ```
6. **校验并修复所有错误**：
   - 脚本返回带错误详情的 JSON
   - 若 `status` 为 `errors_found`，查看 `error_summary` 中的具体错误类型与位置
   - 修掉识别出的错误后再次重算
   - 常见待修错误：
     - `#REF!`：单元格引用无效
     - `#DIV/0!`：除以零
     - `#VALUE!`：公式中的数据类型不对
     - `#NAME?`：无法识别的公式名

### 新建 Excel 文件

```python
# 用 openpyxl 处理公式与格式
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

wb = Workbook()
sheet = wb.active

# 添加数据
sheet['A1'] = 'Hello'
sheet['B1'] = 'World'
sheet.append(['Row', 'of', 'data'])

# 添加公式
sheet['B2'] = '=SUM(A1:A10)'

# 设置格式
sheet['A1'].font = Font(bold=True, color='FF0000')
sheet['A1'].fill = PatternFill('solid', start_color='FFFF00')
sheet['A1'].alignment = Alignment(horizontal='center')

# 列宽
sheet.column_dimensions['A'].width = 20

wb.save('output.xlsx')
```

### 编辑既有 Excel 文件

```python
# 用 openpyxl 以保留公式与格式
from openpyxl import load_workbook

# 加载既有文件
wb = load_workbook('existing.xlsx')
sheet = wb.active  # 或 wb['SheetName'] 指定工作表

# 处理多个工作表
for sheet_name in wb.sheetnames:
    sheet = wb[sheet_name]
    print(f"Sheet: {sheet_name}")

# 修改单元格
sheet['A1'] = 'New Value'
sheet.insert_rows(2)  # 在第 2 行插入
sheet.delete_cols(3)  # 删除第 3 列

# 新增工作表
new_sheet = wb.create_sheet('NewSheet')
new_sheet['A1'] = 'Data'

wb.save('modified.xlsx')
```

## 重算公式

由 openpyxl 创建或修改的 Excel 文件里，公式只是字符串，并没有算好的取值。用提供的 `scripts/recalc.py` 脚本来重算：

```bash
python scripts/recalc.py <excel_file> [timeout_seconds]
```

示例：
```bash
python scripts/recalc.py output.xlsx 30
```

该脚本会：
- 首次运行时自动配置 LibreOffice 宏
- 重算所有工作表中的所有公式
- 扫描**所有**单元格中的 Excel 错误（#REF!、#DIV/0! 等）
- 返回带详细错误位置与数量的 JSON
- 在 Linux 与 macOS 上均可用

## 公式校验清单

用以下快速检查确保公式正确工作：

### 必要校验
- [ ] **先试 2-3 个样本引用**：在建完整模型之前，确认它们取到的值正确
- [ ] **列映射**：确认 Excel 列号对得上（如第 64 列是 BL，不是 BK）
- [ ] **行偏移**：记住 Excel 行号从 1 开始（DataFrame 第 5 行 = Excel 第 6 行）

### 常见陷阱
- [ ] **NaN 处理**：用 `pd.notna()` 检查空值
- [ ] **靠右的列**：财年数据常常落在第 50 列之后 
- [ ] **多处匹配**：搜索所有出现位置，不要只取第一个
- [ ] **除以零**：在公式里用 `/` 之前先检查分母（#DIV/0!）
- [ ] **引用错误**：核对所有单元格引用是否指向预期的单元格（#REF!）
- [ ] **跨表引用**：跨表链接要用正确格式（Sheet1!A1）

### 公式测试策略
- [ ] **从小处着手**：先在 2-3 个单元格上试公式，再大范围应用
- [ ] **核对依赖**：确认公式引用的所有单元格都存在
- [ ] **测试边界情况**：覆盖零、负数与极大值

### 解读 scripts/recalc.py 的输出
脚本返回带错误详情的 JSON：
```json
{
  "status": "success",           // 或 "errors_found"
  "total_errors": 0,              // 错误总数
  "total_formulas": 42,           // 文件中的公式数量
  "error_summary": {              // 仅在发现错误时出现
    "#REF!": {
      "count": 2,
      "locations": ["Sheet1!B5", "Sheet1!C10"]
    }
  }
}
```

## 最佳实践

### 库的选择
- **pandas**：最适合数据分析、批量操作与简单数据导出
- **openpyxl**：最适合复杂格式、公式与 Excel 专有特性

### 使用 openpyxl
- 单元格索引从 1 开始（row=1, column=1 指 A1 单元格）
- 用 `data_only=True` 读取已算好的取值：`load_workbook('file.xlsx', data_only=True)`
- **警告**：以 `data_only=True` 打开后保存，公式会被取值替换并永久丢失
- 大文件：读取用 `read_only=True`，写入用 `write_only=True`
- 公式会被保留但不会求值——用 scripts/recalc.py 更新取值

### 使用 pandas
- 显式指定数据类型以避免推断问题：`pd.read_excel('file.xlsx', dtype={'id': str})`
- 大文件只读需要的列：`pd.read_excel('file.xlsx', usecols=['A', 'C', 'E'])`
- 正确处理日期：`pd.read_excel('file.xlsx', parse_dates=['date_column'])`

## 代码风格约定
**重要**：为 Excel 操作生成 Python 代码时：
- 写最小、简洁的 Python 代码，不加多余注释
- 避免冗长的变量名与冗余操作
- 避免不必要的 print 语句

**对于 Excel 文件本身**：
- 给含复杂公式或重要假设的单元格加批注
- 为硬编码数值标注数据来源
- 为关键计算与模型各区块加上说明